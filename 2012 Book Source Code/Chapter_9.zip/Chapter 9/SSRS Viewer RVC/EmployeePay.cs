﻿namespace SSRS_Viewer_RVC {
    
    
    public partial class EmployeePay {
    }
}

namespace SSRS_Viewer_RVC {
    
    
    public partial class Employees {
		partial class EmployeePayDataTable
		{
		}
	}
}
